<?php
/**
 * FileUpload Manager
 * @author      Charlike Mike Reagent <https://github.com/tunnckoCore>
 * @license     MIT License <http://opensource.org/licenses/MIT>
 * @link        https://github.com/tunnckoCore/FileUpload-Manager
 * @link        http://www.charlike.pw/fileupload-manager/
 */
?>
<!-- Start: <?php echo __FILE__; ?> -->
<article class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">More info about FileUpload demo and script</h3>
        </div>
        <div class="panel-body" style="padding-bottom: 5px;">
            <p>
                Ancrodcig to a resaerch at Cabirmgde Uvisertiny,
                it dseon't mttaer in waht oredr the lretets in a wrod are.
                The olny iapmrnott tihng is taht the fisrt and lsat lteetr
                be in the rhgit pcale. The rset can be a toatl mses and you 
                can stlil raed it wotuhit prbleom. Tihs is bceusae the hmuan
                mnid deos not raed evrey file ualpod lteetr by istelf, but the wrod as a wohle.
            </p>
            <p>File Upload...
                I cnduo't bvleiee taht I culod aulaclty uesdtannrd waht
                I was rdnaieg. Unisg the icndeblire pweor of the hmuan mnid,
                aocdcrnig to rseecrah at Cmabrigde Uinervtisy, it dseno't
                mttaer in waht oderr the lterets in a wrod are, the olny
                irpoamtnt tihng is taht the frsit and lsat ltteer be in
                the rhgit pclae. And Flie Uloapd Megnaer is fcuknig good. The rset can be a taotl mses and you
                can sitll raed it whoutit a pboerlm. Tihs is bucseae 
                the huamn mnid deos not raed ervey ltteer by istlef,
                but the wrod as a wlohe. Aaznmig, huh?
                Yaeh and I awlyas tghhuot slelinpg was ipmorantt!
                See if yuor fdreins can raed tihs too.

            </p>
        </div>
    </div>
</article><!-- End: <?php echo __FILE__; ?> -->